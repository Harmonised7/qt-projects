#include "script.h"

script::script()
{

}
