#ifndef SCRIPT_H
#define SCRIPT_H


class script
{
public:
    script();
};

#endif // SCRIPT_H
