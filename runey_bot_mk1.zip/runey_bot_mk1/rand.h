#ifndef RAND_H
#define RAND_H

#include <QRandomGenerator>

class Rand
{
public:
    int rand( int bound1, int bound2 = 0 );
};
#endif // RAND_H};
